# Advanced Industry

![Logo](icon.png)

> An experimental Mindustry mod that adds unusual blocks, upgraded versions of vanilla blocks, and unique mechanics. Perfect for those looking for different challenges, faster production, and alternative strategies. Not recommended if you take the game too seriously!

## CAUTION

This mod contains:

- Bad sprites, many copied [(from the source code)](https://github.com/Anuken/Mindustry/blob/master/core/assets-raw/sprites/).
- Bad English.
- Dubious ideas.
- Why are you even playing this?

### Changelog

Current version: **1.0**  