//Planets.serpulo.allowSectorInvasion = true;  Removed by convenience.
Planets.serpulo.atmosphereColor = Color.valueOf("#ffee22");
Planets.serpulo.orbitRadius = 70;
Planets.serpulo.ruleSetter = (r) => {
  r.showSpawns = true;
  r.deconstructRefundMultiplier = 1.99;
};
