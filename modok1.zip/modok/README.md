# OP Mod

![Logo](icon.png)

It's a [Mindustry](https://mindustrygame.github.io) mod.

~~That Means Oh Phuck Mod, because yes~~

This mod add new stupid blocks or upgraded(_~~sometimes op~~_) version of vanilla blocks. This doesn't means it's a hack.

## CAUTION

This mod contains:

- Bad Sprites, many copys[(of source code)](https://github.com/Anuken/Mindustry/blob/master/core/assets-raw/sprites/).
- Bad english.
- Bad ideas.
- What do you want playing this?

### Changelog

Actual version: **1.0**
See that shit [here](Changelog.md)
